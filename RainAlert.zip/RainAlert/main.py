from app import app  # noqa: F401
from scheduler import initialize_scheduler

# Initialize the scheduler to perform background weather checks
# This needs to run whether we're using gunicorn or running directly
initialize_scheduler()

if __name__ == "__main__":
    # Start the Flask application (when run directly, not via gunicorn)
    app.run(host="0.0.0.0", port=5000, debug=True)
