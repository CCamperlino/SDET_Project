# Weather App EC2 Deployment Guide

## Database Configuration
The application now uses SQLite instead of PostgreSQL. The database file will be created automatically in the Flask instance folder as `weather_app.db`. On your EC2 instance, the SQLite database file will be created in the same directory where you run the application.

The application is configured with:
```python
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///weather_app.db"
```

This relative path approach will work across both development and production environments.

## Flask Version Compatibility
The app has been updated to work with both Flask 2.x (which is on your EC2 instance) and Flask 3.x (which is in the development environment). We've added a robust monkey patch that prevents the 'partitioned' parameter error you were seeing by patching the Flask session interface directly.

## Deployment Steps

1. Clone the repository to your EC2 instance:
   ```
   git clone <your-repository-url>
   cd <repository-directory>
   ```

2. Install the required packages:
   ```
   pip install email-validator flask-login "flask>=2.2.0,<3.0.0" flask-sqlalchemy gunicorn flask-wtf apscheduler requests sendgrid
   ```

   Note: We're specifically installing Flask 2.x to match your EC2 environment.

3. Start the application:
   ```
   gunicorn --bind 0.0.0.0:5000 main:app
   ```

4. For production, consider setting up a systemd service or using a process manager like Supervisor to keep the application running.

## Environment Variables
Make sure to set these environment variables:
- `SESSION_SECRET`: A secret key for session management
- Any API keys needed for the weather service or email functionality

## Troubleshooting
If you encounter any issues with cookies or sessions, the application now includes a compatibility patch that should fix the 'partitioned' argument issue in Flask 2.x.