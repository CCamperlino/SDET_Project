import requests
import json
import logging
from datetime import datetime, timedelta
from urllib.parse import urlencode

# Setup logging
logger = logging.getLogger(__name__)

# OpenWeatherMap API base URL (free tier with limited functionality)
OPEN_WEATHER_BASE_URL = "https://api.openweathermap.org/data/2.5"

# Open-Meteo API base URL (completely free and open-source)
OPEN_METEO_BASE_URL = "https://api.open-meteo.com/v1"

# Cache for weather data to reduce API calls
weather_cache = {}
forecast_cache = {}
CACHE_DURATION = 30 * 60  # 30 minutes in seconds

def get_current_weather(zipcode, country_code="us"):
    """
    Get current weather data for a location using Open-Meteo API
    """
    cache_key = f"current_{zipcode}"
    
    # Check cache first
    if cache_key in weather_cache:
        cache_time, cache_data = weather_cache[cache_key]
        if datetime.now() - cache_time < timedelta(seconds=CACHE_DURATION):
            return cache_data
    
    # For Open-Meteo, we need to convert zipcode to coordinates
    # Use Open-Meteo Geocoding API
    try:
        geocode_url = f"https://geocoding-api.open-meteo.com/v1/search?name={zipcode}&count=1&language=en&format=json"
        response = requests.get(geocode_url)
        response.raise_for_status()
        geo_data = response.json()
        
        if not geo_data.get('results'):
            logger.error(f"Location not found for zipcode: {zipcode}")
            return None
        
        # Extract coordinates
        location = geo_data['results'][0]
        latitude = location['latitude']
        longitude = location['longitude']
        location_name = location['name']
        
        # Now get the weather data
        params = {
            'latitude': latitude,
            'longitude': longitude,
            'current_weather': 'true',
            'hourly': 'temperature_2m,relativehumidity_2m,precipitation,precipitation_probability,weathercode,windspeed_10m',
            'timezone': 'auto'
        }
        
        url = f"{OPEN_METEO_BASE_URL}/forecast?{urlencode(params)}"
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        
        # Process data into a simpler format
        current = data['current_weather']
        
        # Get current hour's data from hourly forecasts
        current_time = datetime.fromisoformat(current['time'])
        hourly_data = data['hourly']
        hourly_times = [datetime.fromisoformat(t) for t in hourly_data['time']]
        
        # Find the closest hour
        closest_idx = min(range(len(hourly_times)), key=lambda i: abs(hourly_times[i] - current_time))
        
        # Get temperature and convert to Fahrenheit
        celsius_temp = current['temperature']
        fahrenheit_temp = celsius_to_fahrenheit(celsius_temp)
        
        weather_data = {
            'location': location_name,
            'temperature': celsius_temp,
            'temperature_f': fahrenheit_temp,
            'weathercode': current['weathercode'],
            'windspeed': current['windspeed'],
            'humidity': hourly_data['relativehumidity_2m'][closest_idx],
            'precipitation': hourly_data['precipitation'][closest_idx],
            'precipitation_probability': hourly_data['precipitation_probability'][closest_idx],
            'description': get_weather_description(current['weathercode']),
            'timestamp': current['time']
        }
        
        # Cache the result
        weather_cache[cache_key] = (datetime.now(), weather_data)
        
        return weather_data
        
    except Exception as e:
        logger.error(f"Error fetching weather data for {zipcode}: {e}")
        raise

def get_weather_forecast(zipcode, country_code="us", days=3):
    """
    Get weather forecast for a location using Open-Meteo API
    """
    cache_key = f"forecast_{zipcode}_{days}"
    
    # Check cache first
    if cache_key in forecast_cache:
        cache_time, cache_data = forecast_cache[cache_key]
        if datetime.now() - cache_time < timedelta(seconds=CACHE_DURATION):
            return cache_data
    
    try:
        # Convert zipcode to coordinates
        geocode_url = f"https://geocoding-api.open-meteo.com/v1/search?name={zipcode}&count=1&language=en&format=json"
        response = requests.get(geocode_url)
        response.raise_for_status()
        geo_data = response.json()
        
        if not geo_data.get('results'):
            logger.error(f"Location not found for zipcode: {zipcode}")
            return None
        
        # Extract coordinates
        location = geo_data['results'][0]
        latitude = location['latitude']
        longitude = location['longitude']
        
        # Get forecast data
        params = {
            'latitude': latitude,
            'longitude': longitude,
            'hourly': 'temperature_2m,relativehumidity_2m,precipitation,precipitation_probability,weathercode,windspeed_10m',
            'forecast_days': days,
            'timezone': 'auto'
        }
        
        url = f"{OPEN_METEO_BASE_URL}/forecast?{urlencode(params)}"
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        
        # Process hourly data
        hourly = data['hourly']
        forecast = []
        
        for i in range(len(hourly['time'])):
            time = datetime.fromisoformat(hourly['time'][i])
            celsius = hourly['temperature_2m'][i]
            forecast.append({
                'time': time.strftime('%Y-%m-%d %H:%M'),
                'day': time.strftime('%A'),
                'hour': time.strftime('%H:%M'),
                'temperature': celsius,
                'temperature_f': celsius_to_fahrenheit(celsius),
                'humidity': hourly['relativehumidity_2m'][i],
                'precipitation': hourly['precipitation'][i],
                'precipitation_probability': hourly['precipitation_probability'][i],
                'weathercode': hourly['weathercode'][i],
                'windspeed': hourly['windspeed_10m'][i],
                'description': get_weather_description(hourly['weathercode'][i])
            })
        
        # Cache the result
        forecast_cache[cache_key] = (datetime.now(), forecast)
        
        return forecast
        
    except Exception as e:
        logger.error(f"Error fetching forecast for {zipcode}: {e}")
        raise

def get_rain_probability(zipcode, hours_ahead=6):
    """
    Get the highest rain probability in the next few hours
    If it's currently raining, return 100%
    """
    try:
        # First check if it's currently raining
        if is_raining(zipcode):
            return 100
        
        forecast = get_weather_forecast(zipcode)
        if not forecast:
            return 0
        
        # Get the maximum rain probability in the next X hours
        now = datetime.now()
        max_prob = 0
        
        for hour in forecast[:hours_ahead]:
            hour_time = datetime.strptime(hour['time'], '%Y-%m-%d %H:%M')
            if hour_time > now:
                max_prob = max(max_prob, hour['precipitation_probability'])
        
        return max_prob
    except Exception as e:
        logger.error(f"Error getting rain probability for {zipcode}: {e}")
        return 0

def is_raining(zipcode):
    """
    Check if it's currently raining at the location
    """
    try:
        current = get_current_weather(zipcode)
        if not current:
            return False
        
        # Check precipitation and weather code
        # WMO Weather interpretation codes:
        # https://open-meteo.com/en/docs
        # Codes 51-65 are drizzle and rain
        rain_codes = list(range(51, 66)) + [80, 81, 82, 95, 96, 99]
        
        is_rain = current['weathercode'] in rain_codes or current['precipitation'] > 0
        return is_rain
    except Exception as e:
        logger.error(f"Error checking if raining for {zipcode}: {e}")
        return False

def will_rain_soon(zipcode, hours_ahead=3, probability_threshold=30):
    """
    Check if it will rain soon based on the forecast
    """
    try:
        forecast = get_weather_forecast(zipcode)
        if not forecast:
            return False
        
        # Check if rain is predicted in the next X hours
        now = datetime.now()
        rain_codes = list(range(51, 66)) + [80, 81, 82, 95, 96, 99]
        
        for hour in forecast[:hours_ahead]:
            hour_time = datetime.strptime(hour['time'], '%Y-%m-%d %H:%M')
            if hour_time > now:
                if (hour['weathercode'] in rain_codes or 
                    hour['precipitation_probability'] >= probability_threshold):
                    return True
        
        return False
    except Exception as e:
        logger.error(f"Error checking if will rain soon for {zipcode}: {e}")
        return False

def celsius_to_fahrenheit(celsius):
    """
    Convert Celsius temperature to Fahrenheit
    """
    if celsius is None:
        return None
    return (celsius * 9/5) + 32

def get_weather_description(weathercode):
    """
    Convert WMO Weather Code to human-readable description
    Based on https://open-meteo.com/en/docs
    """
    weather_codes = {
        0: "Clear sky",
        1: "Mainly clear",
        2: "Partly cloudy",
        3: "Overcast",
        45: "Fog",
        48: "Depositing rime fog",
        51: "Light drizzle",
        53: "Moderate drizzle",
        55: "Dense drizzle",
        56: "Light freezing drizzle",
        57: "Dense freezing drizzle",
        61: "Slight rain",
        63: "Moderate rain",
        65: "Heavy rain",
        66: "Light freezing rain",
        67: "Heavy freezing rain",
        71: "Slight snow fall",
        73: "Moderate snow fall",
        75: "Heavy snow fall",
        77: "Snow grains",
        80: "Slight rain showers",
        81: "Moderate rain showers",
        82: "Violent rain showers",
        85: "Slight snow showers",
        86: "Heavy snow showers",
        95: "Thunderstorm",
        96: "Thunderstorm with slight hail",
        99: "Thunderstorm with heavy hail"
    }
    
    return weather_codes.get(weathercode, "Unknown")
