import os
import logging

from flask import Flask, render_template, redirect, url_for, flash, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Flask version compatibility monkey patch for Flask 2.x
# This is a more direct approach that will work even if we can't properly detect Flask version
try:
    # Direct monkey patch to Flask's session implementation
    import flask.sessions
    original_save_session = flask.sessions.SecureCookieSessionInterface.save_session
    
    def patched_save_session(self, app, session, response):
        if session.modified:
            # Get the original save_cookie method
            original_set_cookie = response.set_cookie
            
            # Create a wrapper that filters out 'partitioned' parameter
            def set_cookie_without_partitioned(*args, **kwargs):
                kwargs.pop('partitioned', None)
                return original_set_cookie(*args, **kwargs)
            
            # Replace the method temporarily
            response.set_cookie = set_cookie_without_partitioned
            
            # Call the original save_session
            result = original_save_session(self, app, session, response)
            
            # Restore the original method
            response.set_cookie = original_set_cookie
            
            return result
        return original_save_session(self, app, session, response)
    
    # Apply the patch
    flask.sessions.SecureCookieSessionInterface.save_session = patched_save_session
    logger.info("Applied Flask compatibility patch for cookies (direct approach)")
except Exception as e:
    logger.warning(f"Could not apply Flask compatibility patch: {e}")

class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy with the Base class
db = SQLAlchemy(model_class=Base)

# Create the Flask application
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)  # Needed for url_for to generate with https

# Configure the database connection
# Changed from PostgreSQL to SQLite
# Three slashes is a relative path, four slashes would be an absolute path
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///weather_app.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize the database with the app
db.init_app(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# Create all database tables
with app.app_context():
    import models  # noqa: F401
    from models import User, Location, WeatherAlert
    db.create_all()

# User loader for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

# Import route handlers
from forms import LoginForm, RegistrationForm, LocationForm, ForgotPasswordForm, ResetPasswordForm
from weather_api import get_current_weather, get_weather_forecast, get_rain_probability, is_raining
from email_utils import send_reset_password_email

# Routes
@app.route('/')
def index():
    """Home page route"""
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration page"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        from models import User
        from werkzeug.security import generate_password_hash
        
        # Check if user already exists
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.', 'danger')
            return render_template('register.html', form=form)
            
        existing_email = User.query.filter_by(email=form.email.data).first()
        if existing_email:
            flash('Email already registered. Please use a different email.', 'danger')
            return render_template('register.html', form=form)
        
        # Create new user
        user = User(
            username=form.username.data,
            email=form.email.data,
            password_hash=generate_password_hash(form.password.data)
        )
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login page"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        from models import User
        from werkzeug.security import check_password_hash
        
        user = User.query.filter_by(username=form.username.data).first()
        
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            flash('You have been logged in!', 'success')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('Login unsuccessful. Please check your username and password.', 'danger')
    
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    """User logout"""
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    """User dashboard showing saved locations and weather summaries"""
    from models import Location, WeatherAlert
    
    # Get user's saved locations
    locations = Location.query.filter_by(user_id=current_user.id).all()
    
    # Get weather data for each location
    location_weather = []
    for location in locations:
        try:
            current_weather = get_current_weather(location.zipcode)
            rain_prob = get_rain_probability(location.zipcode)
            raining = is_raining(location.zipcode)
            
            # Get recent alerts for this location
            alerts = WeatherAlert.query.filter_by(
                location_id=location.id
            ).order_by(WeatherAlert.timestamp.desc()).limit(3).all()
            
            location_weather.append({
                'location': location,
                'weather': current_weather,
                'rain_probability': rain_prob,
                'is_raining': raining,
                'alerts': alerts
            })
        except Exception as e:
            logger.error(f"Error getting weather for {location.zipcode}: {e}")
            flash(f"Unable to fetch weather data for {location.name} ({location.zipcode})", "warning")
    
    return render_template('dashboard.html', location_weather=location_weather)

@app.route('/add_location', methods=['GET', 'POST'])
@login_required
def add_location():
    """Add a new location to track"""
    form = LocationForm()
    
    if form.validate_on_submit():
        from models import Location
        
        # Check if location already exists for this user
        existing_location = Location.query.filter_by(
            user_id=current_user.id,
            zipcode=form.zipcode.data
        ).first()
        
        if existing_location:
            flash(f'Location with zipcode {form.zipcode.data} already exists', 'warning')
            return redirect(url_for('dashboard'))
        
        # Verify zipcode by calling weather API
        try:
            weather_data = get_current_weather(form.zipcode.data)
            if not weather_data:
                flash('Invalid zipcode or unable to get weather data', 'danger')
                return render_template('add_location.html', form=form)
        except Exception as e:
            logger.error(f"Error verifying zipcode {form.zipcode.data}: {e}")
            flash('Error verifying zipcode, please try again', 'danger')
            return render_template('add_location.html', form=form)
            
        # Create new location
        location = Location(
            name=form.name.data,
            zipcode=form.zipcode.data,
            user_id=current_user.id
        )
        
        db.session.add(location)
        db.session.commit()
        
        flash(f'Location {form.name.data} added successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('add_location.html', form=form)

@app.route('/location/<int:location_id>')
@login_required
def location_detail(location_id):
    """Detailed view for a specific location"""
    from models import Location, WeatherAlert
    
    location = Location.query.filter_by(id=location_id, user_id=current_user.id).first_or_404()
    
    # Get detailed weather information
    try:
        current_weather = get_current_weather(location.zipcode)
        forecast = get_weather_forecast(location.zipcode)
        alerts = WeatherAlert.query.filter_by(location_id=location.id).order_by(WeatherAlert.timestamp.desc()).limit(10).all()
        
        return render_template('location_detail.html', 
                              location=location, 
                              current_weather=current_weather,
                              forecast=forecast,
                              alerts=alerts)
    except Exception as e:
        logger.error(f"Error getting detailed weather for {location.zipcode}: {e}")
        flash("Unable to fetch detailed weather data", "danger")
        return redirect(url_for('dashboard'))

@app.route('/delete_location/<int:location_id>', methods=['POST'])
@login_required
def delete_location(location_id):
    """Delete a location"""
    from models import Location
    
    location = Location.query.filter_by(id=location_id, user_id=current_user.id).first_or_404()
    
    db.session.delete(location)
    db.session.commit()
    
    flash(f'Location {location.name} deleted successfully', 'success')
    return redirect(url_for('dashboard'))

@app.route('/api/get_rainfall_data/<zipcode>')
@login_required
def get_rainfall_data(zipcode):
    """API endpoint to get rainfall data for charts"""
    try:
        forecast = get_weather_forecast(zipcode)
        
        # Extract the hourly rainfall probability for the next 24 hours
        rainfall_data = {
            'labels': [entry.get('time', 'Unknown') for entry in forecast[:24]],
            'datasets': [{
                'label': 'Rainfall Probability (%)',
                'data': [entry.get('precipitation_probability', 0) for entry in forecast[:24]],
                'backgroundColor': 'rgba(54, 162, 235, 0.2)',
                'borderColor': 'rgba(54, 162, 235, 1)',
                'borderWidth': 1
            }]
        }
        
        return jsonify(rainfall_data)
    except Exception as e:
        logger.error(f"Error getting rainfall data for {zipcode}: {e}")
        return jsonify({'error': 'Unable to fetch rainfall data'}), 500

# Password reset routes
@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    """Forgot password page"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = ForgotPasswordForm()
    if form.validate_on_submit():
        from models import User
        
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            # Generate reset token
            token = user.generate_reset_token()
            
            # Create reset link
            reset_link = url_for('reset_password', token=token, _external=True)
            
            # Send email with reset link
            if send_reset_password_email(user.email, reset_link):
                flash('Password reset instructions have been sent to your email.', 'info')
            else:
                flash('Error sending email. Please try again later.', 'danger')
        else:
            # To prevent user enumeration, still show success message even if email not found
            flash('If this email exists in our system, password reset instructions have been sent.', 'info')
            
        return redirect(url_for('login'))
    
    return render_template('forgot_password.html', form=form)

@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    """Reset password page"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    from models import User
    
    # Find user with this token
    user = User.query.filter_by(reset_token=token).first()
    
    # Verify token is valid
    if not user or not user.verify_reset_token(token):
        flash('The password reset link is invalid or has expired.', 'danger')
        return redirect(url_for('forgot_password'))
    
    form = ResetPasswordForm()
    if form.validate_on_submit():
        # Update user's password
        user.password_hash = generate_password_hash(form.password.data)
        # Clear the reset token
        user.clear_reset_token()
        
        db.session.commit()
        
        flash('Your password has been updated! You can now log in with your new password.', 'success')
        return redirect(url_for('login'))
    
    return render_template('reset_password.html', form=form)

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500
