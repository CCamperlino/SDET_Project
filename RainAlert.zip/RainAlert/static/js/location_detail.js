/**
 * Location Detail JS
 * JavaScript for the location detail page functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Set up auto-refresh of weather data
    setInterval(function() {
        // Check if we're still on the location detail page
        if (document.getElementById('location-map')) {
            location.reload();
        }
    }, 10 * 60 * 1000); // Refresh every 10 minutes
});
