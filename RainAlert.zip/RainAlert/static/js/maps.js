/**
 * Maps JS
 * JavaScript for initializing and controlling weather visualizations
 */

/**
 * Initialize a weather radar display for a location
 * @param {string} containerId - The HTML ID of the container
 * @param {string} zipcode - The zipcode of the location to show radar for
 */
function initWeatherRadar(containerId, zipcode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  
  // Clear the container
  container.innerHTML = '';
  
  // Create radar container and header
  const radarDiv = document.createElement('div');
  radarDiv.className = 'radar-container text-center my-3';
  
  // Create loading indicator
  const loadingDiv = document.createElement('div');
  loadingDiv.className = 'spinner-border text-primary';
  loadingDiv.setAttribute('role', 'status');
  loadingDiv.innerHTML = '<span class="visually-hidden">Loading...</span>';
  radarDiv.appendChild(loadingDiv);
  
  // Add to container
  container.appendChild(radarDiv);
  
  // Get current timestamp for URL cache busting
  const timestamp = new Date().getTime();
  
  // Set up rain viewer radar (public, no API key needed)
  // Generate the URL for RainViewer radar
  setTimeout(() => {
    // Remove loading indicator
    loadingDiv.remove();
    
    // Use geocoding to get lat/lon from zipcode
    fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${zipcode}&count=1&language=en&format=json`)
      .then(response => response.json())
      .then(data => {
        if (data && data.results && data.results.length > 0) {
          const location = data.results[0];
          const lat = location.latitude;
          const lon = location.longitude;
          
          // Create and append the iframe with RainViewer
          const iframe = document.createElement('iframe');
          iframe.src = `https://www.rainviewer.com/map.html?loc=${lat},${lon},8&oFa=0&oC=1&oU=0&oCS=1&oF=0&oAP=0&c=1&o=83&lm=1&th=0&sm=1&sn=1`;
          iframe.width = '100%';
          iframe.height = '400';
          iframe.frameBorder = '0';
          iframe.style.borderRadius = '8px';
          iframe.scrolling = 'no';
          iframe.allowFullScreen = true;
          
          // Add caption
          const caption = document.createElement('div');
          caption.className = 'text-center mt-2 text-muted';
          caption.textContent = 'Live Precipitation Radar';
          
          radarDiv.appendChild(iframe);
          radarDiv.appendChild(caption);
        } else {
          showRadarError(radarDiv);
        }
      })
      .catch(error => {
        console.error('Error loading radar:', error);
        showRadarError(radarDiv);
      });
  }, 500);
}

/**
 * Display error message when radar can't be loaded
 * @param {HTMLElement} container - The container to show error in
 */
function showRadarError(container) {
  container.innerHTML = `
    <div class="alert alert-warning" role="alert">
      <i class="fas fa-exclamation-triangle me-2"></i>
      Unable to load weather radar. Please try again later.
    </div>
  `;
}

/**
 * Legacy function for backward compatibility
 * @param {string} mapId - The HTML ID of the map container
 * @param {Array} locations - Array of location objects with coordinates and weather data
 */
function initWeatherMap(mapId, locations) {
  console.log('Weather map functionality has been replaced with weather radar');
  const container = document.getElementById(mapId);
  if (container) {
    container.innerHTML = '<div class="alert alert-info">Weather maps have been upgraded to interactive radar. Please view individual location details.</div>';
  }
}
