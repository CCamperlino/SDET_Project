/**
 * Dashboard.js
 * JavaScript for the dashboard page functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Set up auto-refresh of weather data
    setInterval(function() {
        // Check if we're still on the dashboard page
        if (document.getElementById('weather-map')) {
            location.reload();
        }
    }, 15 * 60 * 1000); // Refresh every 15 minutes
});
