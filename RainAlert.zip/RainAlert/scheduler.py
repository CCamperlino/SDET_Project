from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
import logging
from datetime import datetime

# Setup logging
logger = logging.getLogger(__name__)

def initialize_scheduler():
    """Initialize the background scheduler for weather checks"""
    scheduler = BackgroundScheduler()
    
    # Add jobs
    scheduler.add_job(
        func=check_rain_alerts,
        trigger=IntervalTrigger(minutes=30),  # Run every 30 minutes
        id='rain_alert_job',
        name='Check for rain alerts',
        replace_existing=True
    )
    
    # Start the scheduler
    scheduler.start()
    logger.info("Started background scheduler for weather alerts")
    
    return scheduler

def check_rain_alerts():
    """
    Background job to check for rain alerts for all users' locations
    This is run periodically by the scheduler
    """
    from app import app, db
    from models import Location, WeatherAlert
    from weather_api import get_current_weather, will_rain_soon, is_raining
    
    with app.app_context():
        logger.info(f"Running rain alert check at {datetime.now()}")
        
        # Get all locations
        locations = Location.query.all()
        
        for location in locations:
            try:
                # Check current weather
                current_weather = get_current_weather(location.zipcode)
                
                if not current_weather:
                    logger.warning(f"Could not get weather data for {location.name} ({location.zipcode})")
                    continue
                
                # Check if it's currently raining
                raining_now = is_raining(location.zipcode)
                
                # Check if it will rain soon
                rain_coming = will_rain_soon(location.zipcode)
                
                # Create alerts based on conditions
                if raining_now:
                    # Check if we already have a recent "raining_now" alert
                    recent_alert = WeatherAlert.query.filter_by(
                        location_id=location.id,
                        alert_type='raining_now'
                    ).order_by(WeatherAlert.timestamp.desc()).first()
                    
                    # Only create a new alert if we don't have a recent one (within 2 hours)
                    if not recent_alert or (datetime.utcnow() - recent_alert.timestamp).total_seconds() > 7200:
                        alert = WeatherAlert(
                            message=f"It's currently raining in {location.name}",
                            alert_type='raining_now',
                            temperature=current_weather['temperature'],
                            humidity=current_weather['humidity'],
                            precipitation_probability=current_weather['precipitation_probability'],
                            location_id=location.id
                        )
                        db.session.add(alert)
                
                if rain_coming and not raining_now:
                    # Check if we already have a recent "rain_soon" alert
                    recent_alert = WeatherAlert.query.filter_by(
                        location_id=location.id,
                        alert_type='rain_soon'
                    ).order_by(WeatherAlert.timestamp.desc()).first()
                    
                    # Only create a new alert if we don't have a recent one (within 2 hours)
                    if not recent_alert or (datetime.utcnow() - recent_alert.timestamp).total_seconds() > 7200:
                        alert = WeatherAlert(
                            message=f"Rain expected soon in {location.name}",
                            alert_type='rain_soon',
                            temperature=current_weather['temperature'],
                            humidity=current_weather['humidity'],
                            precipitation_probability=current_weather['precipitation_probability'],
                            location_id=location.id
                        )
                        db.session.add(alert)
                
                # Commit any new alerts
                db.session.commit()
                
            except Exception as e:
                logger.error(f"Error checking rain alerts for {location.name} ({location.zipcode}): {e}")
                db.session.rollback()
        
        logger.info(f"Completed rain alert check at {datetime.now()}")
