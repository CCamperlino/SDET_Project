from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError

class RegistrationForm(FlaskForm):
    """Form for user registration"""
    username = StringField('Username', 
                           validators=[DataRequired(), Length(min=3, max=50)],
                           render_kw={"placeholder": "Enter username"})
    
    email = StringField('Email',
                        validators=[DataRequired(), Email()],
                        render_kw={"placeholder": "Enter email"})
    
    password = PasswordField('Password',
                             validators=[DataRequired(), Length(min=6)],
                             render_kw={"placeholder": "Enter password"})
    
    confirm_password = PasswordField('Confirm Password',
                                     validators=[DataRequired(), EqualTo('password')],
                                     render_kw={"placeholder": "Confirm password"})
    
    submit = SubmitField('Sign Up')

class LoginForm(FlaskForm):
    """Form for user login"""
    username = StringField('Username',
                           validators=[DataRequired()],
                           render_kw={"placeholder": "Enter username"})
    
    password = PasswordField('Password',
                             validators=[DataRequired()],
                             render_kw={"placeholder": "Enter password"})
    
    remember = BooleanField('Remember Me')
    
    submit = SubmitField('Login')

class ForgotPasswordForm(FlaskForm):
    """Form for resetting password"""
    email = StringField('Email',
                        validators=[DataRequired(), Email()],
                        render_kw={"placeholder": "Enter your registered email"})
    
    submit = SubmitField('Send Reset Link')

class ResetPasswordForm(FlaskForm):
    """Form for setting a new password after reset"""
    password = PasswordField('New Password',
                             validators=[DataRequired(), Length(min=6)],
                             render_kw={"placeholder": "Enter new password"})
    
    confirm_password = PasswordField('Confirm New Password',
                                     validators=[DataRequired(), EqualTo('password')],
                                     render_kw={"placeholder": "Confirm new password"})
    
    submit = SubmitField('Reset Password')

class LocationForm(FlaskForm):
    """Form for adding a location"""
    name = StringField('Location Name',
                       validators=[DataRequired(), Length(min=1, max=100)],
                       render_kw={"placeholder": "e.g., Home, Work, Vacation House"})
    
    zipcode = StringField('Zip Code',
                          validators=[DataRequired(), Length(min=5, max=10)],
                          render_kw={"placeholder": "Enter zip code"})
    
    submit = SubmitField('Add Location')
