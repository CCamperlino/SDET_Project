from datetime import datetime, timedelta
import secrets
from app import db
from flask_login import UserMixin

class User(UserMixin, db.Model):
    """User model for authentication and profile management"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reset_token = db.Column(db.String(100), nullable=True)
    reset_token_expiration = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    locations = db.relationship('Location', backref='user', lazy=True, cascade="all, delete-orphan")
    
    def generate_reset_token(self):
        """Generate a password reset token that expires in 1 hour"""
        self.reset_token = secrets.token_urlsafe(32)
        self.reset_token_expiration = datetime.utcnow() + timedelta(hours=1)
        return self.reset_token
    
    def verify_reset_token(self, token):
        """Verify if the reset token is valid"""
        if (token != self.reset_token or 
            self.reset_token_expiration is None or 
            datetime.utcnow() > self.reset_token_expiration):
            return False
        return True
    
    def clear_reset_token(self):
        """Clear the reset token after use"""
        self.reset_token = None
        self.reset_token_expiration = None
    
    def __repr__(self):
        return f'<User {self.username}>'

class Location(db.Model):
    """Locations saved by users to track weather"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    zipcode = db.Column(db.String(10), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign key
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationships
    weather_alerts = db.relationship('WeatherAlert', backref='location', lazy=True, cascade="all, delete-orphan")
    
    def __repr__(self):
        return f'<Location {self.name} ({self.zipcode})>'

class WeatherAlert(db.Model):
    """Weather alerts for rain predictions"""
    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.String(255), nullable=False)
    alert_type = db.Column(db.String(50), nullable=False)  # e.g., "rain_soon", "heavy_rain", etc.
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Weather data at time of alert
    temperature = db.Column(db.Float, nullable=True)
    humidity = db.Column(db.Float, nullable=True)
    precipitation_probability = db.Column(db.Float, nullable=True)
    
    # Foreign key
    location_id = db.Column(db.Integer, db.ForeignKey('location.id'), nullable=False)
    
    def __repr__(self):
        return f'<WeatherAlert {self.alert_type} at {self.timestamp}>'
