import os
import sys
import logging
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Email, To, Content

# Setup logging
logger = logging.getLogger(__name__)

def send_reset_password_email(to_email, reset_link):
    """
    Send a password reset email with a link to reset the password
    """
    try:
        # Get the SendGrid API key from environment variables
        sendgrid_api_key = os.environ.get('SENDGRID_API_KEY')
        if not sendgrid_api_key:
            logger.error("SENDGRID_API_KEY environment variable not set")
            return False
            
        # Create the email message
        # This should be changed to a verified email address in SendGrid
        from_email = os.environ.get('SENDGRID_FROM_EMAIL', 'user@example.com')
        subject = "Rain Radar - Password Reset"
        
        # Create HTML email content
        html_content = f"""
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background-color: #3498db; color: white; padding: 20px; text-align: center; }}
                .content {{ padding: 20px; }}
                .button {{ background-color: #3498db; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }}
                .footer {{ margin-top: 20px; font-size: 12px; color: #777; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Rain Radar Password Reset</h1>
                </div>
                <div class="content">
                    <p>Hello,</p>
                    <p>We received a request to reset your password for your Rain Radar account. Click the button below to reset it:</p>
                    <p style="text-align: center; margin: 30px 0;">
                        <a href="{reset_link}" class="button">Reset My Password</a>
                    </p>
                    <p>If you did not request a password reset, please ignore this email or contact support if you have concerns.</p>
                    <p>This link will expire in 1 hour for security reasons.</p>
                    <p>Thank you,<br>The Rain Radar Team</p>
                </div>
                <div class="footer">
                    <p>This is an automated message, please do not reply to this email.</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        # Create plain text content as a fallback
        text_content = f"""
        Rain Radar Password Reset
        
        Hello,
        
        We received a request to reset your password for your Rain Radar account. 
        Please click the link below to reset it:
        
        {reset_link}
        
        If you did not request a password reset, please ignore this email or contact support if you have concerns.
        
        This link will expire in 1 hour for security reasons.
        
        Thank you,
        The Rain Radar Team
        """
        
        # Create the SendGrid email object
        message = Mail(
            from_email=Email(from_email),
            to_emails=To(to_email),
            subject=subject,
            html_content=Content("text/html", html_content),
            plain_text_content=Content("text/plain", text_content)
        )
        
        # Send the email
        sg = SendGridAPIClient(sendgrid_api_key)
        response = sg.send(message)
        
        # Log the response
        logger.info(f"Password reset email sent to {to_email}, status code: {response.status_code}")
        
        return response.status_code == 202
        
    except Exception as e:
        logger.error(f"Error sending password reset email: {e}")
        return False